package application;

//import controller.Controller;
import model.Model;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {


    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("application/view.fxml"));
        stage.setTitle("Ocean view");
        Scene scene = new Scene(root);

        Model model = new Model();
        //model.setCurrSearch("a");
        //model.queryDataVerbose();
        //Controller c2D = new Controller();
        stage.setScene(scene);

        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
