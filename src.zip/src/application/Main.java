package application;

import model.Model;
import view.View;
import controller.Controller;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

	public static Controller controller;

    @Override
    public void start(Stage stage) throws Exception {
        Model model = new Model();
        controller = new Controller(model);
        Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("application/view.fxml"));
        stage.setTitle("Ocean view");
        Scene scene = new Scene(root);

        //model.setCurrSearch("a");
        //model.queryDataVerbose();
        
        //view.loadJSONData("Delphinidae.JSON");
        
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
