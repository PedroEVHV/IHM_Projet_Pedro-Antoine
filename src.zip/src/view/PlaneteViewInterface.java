package view;

public interface PlaneteViewInterface {
	
	/**
     * Method specific for loading the Earth model in a 3D view.
     */
    public void loadEarth();

}
