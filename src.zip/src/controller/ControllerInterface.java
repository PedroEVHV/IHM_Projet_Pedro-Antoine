package controller;

public interface ControllerInterface {

}
