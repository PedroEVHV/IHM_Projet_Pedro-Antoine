package controller;

import java.util.HashMap;

import model.Model;

public class Controller implements ControllerInterface {
	
	private Model model;
	
	public Controller(Model model)
	{
		this.model = model;
	}
	
	public HashMap<String, Integer> loadDataFromJSON(String file) {
		return model.coordFromJSONObject(model.fileToJSONObject(file));
	}
	
	public int[] loadLegend() {
		return model.legendCouleur();
	}
	
	public HashMap<String, Integer> loadSpeciesDataFromURL(String name, int precision){
		return model.coordFromJSONObject(model.readJsonFromUrl("https://api.obis.org/v3/occurrence/grid/"+precision+"?scientificname="+name));
	}
	
	public HashMap<String, Integer> loadSpeciesDataWithDateFromURL(String name, int precision, String start, String end){
		return model.coordFromJSONObject(model.readJsonFromUrl("https://api.obis.org/v3/occurrence/grid/"+precision+"?scientificname="+name+"&startdate="+start+"&enddate="+end));
	}
	
	public String coordToGeoHash(float lat, float lng) {
		return model.coordToGeoHash(lat, lng);
	}
	
	public String coordToGeoHashWithPrecision(float lat, float lng, int p) {
		return model.coordToGeoHashWithPrecision(lat, lng, p);
	}
}
