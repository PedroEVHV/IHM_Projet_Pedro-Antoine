package controller;

import java.util.HashMap;

import model.Model;

public class Controller implements ControllerInterface {
	
	private Model model;
	
	public Controller(Model model)
	{
		this.model = model;
	}
	
	public HashMap<String, Integer> loadDataFromJSON(String file) {
		return model.coordFromJSONObject(model.fileToJSONObject(file));
	}
}
