package controller;

public class Controller implements ControllerInterface {
}
