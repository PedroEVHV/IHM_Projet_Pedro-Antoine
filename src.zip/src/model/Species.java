package model;

public class Species {
}
