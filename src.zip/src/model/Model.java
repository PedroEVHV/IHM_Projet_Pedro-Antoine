package model;

import java.io.BufferedReader;
import java.io.FileReader;
//import javafx.stage.Screen;
import java.io.IOException;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
//import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;
import geoHash.GeoHashHelper;
import geoHash.Location;

public class Model {
    private String searchBasic = " https://api.obis.org/v3/taxon/complete/verbose/";
    private String currSearch;
    private int occMax = 0;
    private HashMap<String, Integer> geoHashList;

    public int[] legendCouleur() {
    	int[] buf = new int[8];
    	for(int i = 1; i < 8; i++) {
    		buf[i]= (int) (occMax/(Math.pow((8-i), 4)));
    	}
    	return buf;
    }
    
    public String coordToGeoHash(float lat, float lng) {
    	Location loc = new Location("GeoHash", lat, lng);
    	return GeoHashHelper.getGeohash(loc, 3);
    }
    
    public String coordToGeoHashWithPrecision(float lat, float lng, int p) {
    	Location loc = new Location("GeoHash", lat, lng);
    	return GeoHashHelper.getGeohash(loc, p);
    }
    
    private double[] center(JSONArray j1, JSONArray j2) {
		double[] buf = {0, 0};
		buf[0] = (j1.getDouble(0) + j2.getDouble(0))/2;
		buf[1] = (j1.getDouble(1) + j2.getDouble(1))/2;
		
		return buf;
	}

    public Model() {
        //searchBasic = " https://api.obis.org/v3/taxon/complete/verbose/";
    }

    public void setCurrSearch(String currSearch) {
        this.currSearch = searchBasic + currSearch;
    }
    
	
	private String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}
	
	public JSONObject fileToJSONObject(String file) {
		JSONObject jsonRoot = null;
		try(Reader reader = new FileReader(file)){
			BufferedReader rd = new BufferedReader(reader);
			String jsonText = readAll(rd);
			jsonRoot = new JSONObject(jsonText);
		}catch(IOException e) {
			e.printStackTrace();
		}
		return jsonRoot;
	}
	
	int occurance = 0;
	public HashMap<String, Integer> coordFromJSONObject(JSONObject obj) {
		geoHashList = new HashMap<>();
		JSONArray featuresArray = obj.getJSONArray("features");
		featuresArray.forEach(item->{
			JSONObject object = (JSONObject) item;
			JSONObject geometry = object.getJSONObject("geometry");
			
			JSONObject occ = object.getJSONObject("properties");
			occurance = (int) occ.get("n");
			if(occurance > occMax) {
				occMax = occurance;
			}
			
			JSONArray coordsArray = geometry.getJSONArray("coordinates");
			coordsArray.forEach(item2->{
				JSONArray coord = (JSONArray) item2;
				double[] c = center((JSONArray) coord.get(0), (JSONArray) coord.get(2));
				Location loc = new Location("GeoHash", c[1], c[0]);
				geoHashList.put(GeoHashHelper.getGeohash(loc, 3), occurance);
			});		
		});
		return geoHashList;
	}
	
	public JSONObject readJsonFromUrl(String url) { //This method send a json found by an url
        String json = "";
        HttpClient client = HttpClient.newBuilder()
                .version(Version.HTTP_1_1)
                .followRedirects(Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(20))
                .build();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofMinutes(2))
                .header("Content-Type","application/json")
            .GET()
            .build();

        try {
            json = client.sendAsync(request, BodyHandlers.ofString())
                    .thenApply(HttpResponse::body).get(10,TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new JSONObject(json);
    }

    public void queryDataVerbose() throws IOException {
        URL url = new URL(currSearch);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.connect();

        int responseCode = connection.getResponseCode();

        if(responseCode != 200) {
            throw new RuntimeException("code:" + responseCode);
        } else {
            StringBuilder infoString = new StringBuilder();
            Scanner scanner = new Scanner(url.openStream());
            while (scanner.hasNext()) {
                infoString.append(scanner.nextLine());
            }
            scanner.close();
            //System.out.println(infoString.charAt(0));
        }
    }
}
